
public class App {

	public static void main(String[] Args) {
		
	
		Cine cine = new Cine();
		
		cine.iniciar();
		
	}

}
