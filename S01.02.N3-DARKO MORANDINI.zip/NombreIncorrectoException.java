
public class NombreIncorrectoException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public NombreIncorrectoException() {
		
	}

	public NombreIncorrectoException(String mensajeError) {
		
		super(mensajeError);
	}
}
