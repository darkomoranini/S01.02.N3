
public class Butaca {

	private int numeroFila;
	private int numeroButaca;
	private String nombrePersona;
	
	public Butaca(int numeroFila, int numeroButaca, String nombrePersona) {
		this.numeroFila = numeroFila;
		this.numeroButaca = numeroButaca;
		this.nombrePersona = nombrePersona;
	}

	public int getNumeroFila() {
		return numeroFila;
	}

	public void setNumeroFila(int numeroFila) {
		this.numeroFila = numeroFila;
	}

	public int getNumeroButaca() {
		return numeroButaca;
	}

	public void setNumeroButaca(int numeroButaca) {
		this.numeroButaca = numeroButaca;
	}

	public String getNombrePersona() {
		return nombrePersona;
	}

	public void setNombrePersona(String nombrePersona) {
		this.nombrePersona = nombrePersona;
	}
	
	public boolean iguales(int numeroFila1, int numeroButaca1) {
		
		return numeroFila1==numeroFila&&numeroButaca1==numeroButaca;
	}
	
	@Override
	public String toString() {
		
		return "Fila: "+numeroFila+", Asiento: "+numeroButaca;
	}
}
