import java.util.ArrayList;

public class GestionButacas {

	private ArrayList<Butaca>listaButacas;

	public GestionButacas() {

		listaButacas= new  ArrayList<Butaca>();
	}

	public ArrayList<Butaca> getListaButacas() {
		return listaButacas;
	}

	public void setListaButacas(ArrayList<Butaca> listaButacas) {
		this.listaButacas = listaButacas;
	}

	public void addButaca(Butaca butaca) throws IllegalArgumentException {

		if (butaca == null) {
			throw new IllegalArgumentException("El objeto butaca es nulo");
		}
		listaButacas.add(butaca);
	}

	public int buscarButaca(String nombre) throws ListaVaciaException {
		if (listaButacas.isEmpty()) {
			throw new ListaVaciaException();
		}
		int resultado=-1;
		for (int i = 0; i < listaButacas.size(); i++) {
			if (nombre.equalsIgnoreCase(listaButacas.get(i).getNombrePersona())) {
				resultado = i;
			}
		}
		return resultado;
	}

	public int buscarButaca1(int numeroFila, int numeroButaca) throws ListaVaciaException {

		if (listaButacas.isEmpty()) {
			throw new ListaVaciaException();
		}
		int resultado = -1;
		for (int i = 0; i < listaButacas.size(); i++) {
			if (numeroFila==listaButacas.get(i).getNumeroFila()&&numeroButaca==listaButacas.get(i).getNumeroButaca()) {
				resultado = i;
			}
		}
		return resultado;
	}

	public void eliminarButacas(String nombre) throws ListaVaciaException, IllegalArgumentException {

		if (nombre == null) {
			throw new IllegalArgumentException("El nombre no puede ser nulo");
		}
		if (listaButacas.isEmpty()) {
			throw new ListaVaciaException();
		}		
		for (Butaca butaca : getListaButacas()) {
			if(butaca.getNombrePersona().equalsIgnoreCase(nombre)) {
				listaButacas.remove(buscarButaca(nombre));
			}
		}
	}

	public void eliminarButaca(int numeroFila, int numeroButaca) throws ListaVaciaException {
		if (listaButacas.isEmpty()) {
			throw new ListaVaciaException();
		}

		listaButacas.remove(buscarButaca1(numeroFila, numeroButaca));
	}
}
