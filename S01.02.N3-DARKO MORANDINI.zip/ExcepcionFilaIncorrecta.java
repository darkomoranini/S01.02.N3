
public class ExcepcionFilaIncorrecta extends Exception {
	
	private static final long serialVersionUID = 1L;
	
	public ExcepcionFilaIncorrecta(String mensajeError) {
		
		super(mensajeError);
	}

}
