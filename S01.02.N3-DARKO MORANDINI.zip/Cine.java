import java.util.Iterator;

public class Cine {

	private int numeroFilas;
	private int asientosxFila;
	private GestionButacas gestionButacas;

	public Cine() {
		
		gestionButacas = new GestionButacas();
		pedirDatosIniciales( Teclado.leerInt("numero de filas del cine"), Teclado.leerInt("numero de butacas por fila del cine"));
	} 
	
	public void iniciar() {
		int opcion=1;
		while(opcion!=0) {
			switch(menu()) {

			case 0:
				System.exit(0);
				break;

			case 1:
				try {
					mostrarButacasReservadas();
				} catch (ListaVaciaException e) {
					System.out.println("lista vacia");
				}
					break;

			case 2:
				try {
					mostrarButacasReservadasPersona(Teclado.leerString("nombre"));
				} catch (NombreIncorrectoException e) {
					System.out.println("nombre incorrecto");
				} catch (ListaVaciaException e) {
					System.out.println("Lista vacia");
				}
				break;

			case 3:
				try {
					reservarButaca(Teclado.leerInt("numero de fila"), Teclado.leerInt("numero de butaca"), Teclado.leerString("nombre"));
				} catch (ExcepcionFilaIncorrecta | ExcepcionButacaIncorrecta e) {
					System.out.println("numero de butaca o fila fuera de limites");
				} catch (NombreIncorrectoException e) {
					System.out.println("nombre incorrecto");
				}
				break;

			case 4:
				try {
					try {
						anularReserva(Teclado.leerInt("numero de fila"), Teclado.leerInt("numero de butaca"));
						System.out.println("Reserva cancelada");
					} catch (ListaVaciaException e) {
						System.out.println("Lista vacia");
					}
				} catch (ExcepcionFilaIncorrecta e) {
					System.out.println("fila fuera de limites");
				} catch (ExcepcionButacaIncorrecta o) {
					System.out.println("butaca fuera de limites");
				}catch (ArrayIndexOutOfBoundsException i) {
					System.out.println("no se han encontrado reservas");
				}
					break;

			case 5:
				try {					
					anularReservaPersona(Teclado.leerString(Teclado.leerString("nombre")));
					System.out.println("Todas las reservas han sido canceladas");
					} catch (ArrayIndexOutOfBoundsException e) {
						System.out.println("no se han encontrado reservas");
					} catch (ListaVaciaException e) {					
						System.out.println("Lista vacia");
					} catch (NombreIncorrectoException e) {
					System.out.println("formato de nombre incorretco");
					}
					break;
				}
			}	
		}
	

	public int menu() {
		
		int opcion=Teclado.leerInt("0.-SALIR 1.-VER BUTACAS RESERVADAS 2.-VER BUTACAS RESERVADAS/PERSONA "
					  + "3.-RESERVAR 4.-ANULAR RESERVA BUTACA 5.-ANULAR TODAS LAS RESERVAS/PERSONA");
		return opcion;
	}
	
	public void mostrarButacasReservadas() throws ListaVaciaException{
		
		if(gestionButacas.getListaButacas().isEmpty()) {
			throw new ListaVaciaException("lista vacia");
		
		}else {
			System.out.println(gestionButacas.getListaButacas().toString());
		}
	}
	
	public void mostrarButacasReservadasPersona(String nombre) throws NombreIncorrectoException, ListaVaciaException {
		String butacas = "";
	        if(!introducePersona(nombre)) {
	        	throw new NombreIncorrectoException("nombre incorrecto");
	        }
	        if(gestionButacas.getListaButacas().isEmpty()) {
	        	throw new ListaVaciaException("lista vacia");
	        }
	        for (Butaca butaca : gestionButacas.getListaButacas()) {
	        	if (nombre.equalsIgnoreCase(butaca.getNombrePersona())) {
	        		butacas += butaca.toString();
	        	}
	        }
			System.out.println(butacas);
		
		}
	
	
	public void pedirDatosIniciales(int numeroFilas, int asientosxFila) {
		
		this.numeroFilas=numeroFilas;
		this.asientosxFila=asientosxFila;
	}

	public void reservarButaca(int numeroFila, int numeroButaca, String nombre) throws ExcepcionFilaIncorrecta, ExcepcionButacaIncorrecta, NombreIncorrectoException {
	    if (!introducePersona(nombre)) {
	        throw new NombreIncorrectoException("Nombre incorrecto");
	    } else {
	        try {
	            introduceNumeroFila(numeroFila);
	            introduceNumeroButaca(numeroButaca);
	        } catch (ExcepcionFilaIncorrecta | ExcepcionButacaIncorrecta e) {
	            throw e; 
	        }
	    } 
	    gestionButacas.addButaca(new Butaca(numeroFila, numeroButaca, nombre));
	    System.out.println("Butaca reservada");
	}
	
	public void anularReserva(int numeroFila, int numeroButaca) throws ExcepcionFilaIncorrecta, ExcepcionButacaIncorrecta, ArrayIndexOutOfBoundsException, ListaVaciaException {
		try {
			introduceNumeroFila(numeroFila);
		} catch (ArrayIndexOutOfBoundsException e) {
			throw new ExcepcionFilaIncorrecta("Fila fuera de límites o no encontrada");
		}

		try {
			introduceNumeroButaca(numeroButaca);
		} catch (ArrayIndexOutOfBoundsException i) {
			throw new ExcepcionButacaIncorrecta("Butaca fuera de límites o no encontrada");
		}
		try {
		gestionButacas.eliminarButaca(numeroFila, numeroButaca);
		System.out.println("Reservada eliminada");
		}catch(ArrayIndexOutOfBoundsException e){
			System.out.println("Reserva inexistente");
		}
		}
	
	public void anularReservaPersona(String nombre) throws NombreIncorrectoException, ListaVaciaException,  ArrayIndexOutOfBoundsException {
		 	
			if(gestionButacas.getListaButacas().isEmpty()) {
	        	throw new ListaVaciaException("lista vacia");
	        }
			if(!introducePersona(nombre)) {
	        	throw new NombreIncorrectoException("nombre incorrecto");
	        }
	       try {
			Iterator<Butaca> iterator = gestionButacas.getListaButacas().iterator();
	        while (iterator.hasNext()) {
	            Butaca butaca = iterator.next();
	            if (nombre.equalsIgnoreCase(butaca.getNombrePersona())) {
	                iterator.remove();
	                System.out.println("Reserva a nombre de "+nombre+" cancelada");
	            }
	        }   
	       }catch(ArrayIndexOutOfBoundsException e) {
	    	   System.out.println("Reserva no encontrada");
	       }
	 }
			
	public boolean introducePersona(String nombre)  throws NombreIncorrectoException{
		 
		boolean result=true;
		for (char caracter : nombre.toCharArray()) {
			if (Character.isDigit(caracter)) {
				result=false;
				throw new NombreIncorrectoException();
	        }
		}
	        return result;
	}
	
	public int introduceNumeroFila(int numeroFila) throws ExcepcionFilaIncorrecta {
		if(numeroFila < 0 || numeroFila > numeroFilas) {
			throw new ExcepcionFilaIncorrecta("Número de fila fuera de límites");
		}
			return numeroFila;
		
	}

	public int introduceNumeroButaca(int numeroButaca) throws ExcepcionButacaIncorrecta {
		
		if(numeroButaca<0||numeroButaca>asientosxFila) {
			throw new ExcepcionButacaIncorrecta("numero de butaca fuera de limites");
		
		}
			return numeroButaca;
	}	
}

	
