
public class ExcepcionButacaIncorrecta extends Exception {
	
	private static final long serialVersionUID = 1L; 
	
	public ExcepcionButacaIncorrecta(String mensajeError) {
		
		super(mensajeError);		
	}
}
